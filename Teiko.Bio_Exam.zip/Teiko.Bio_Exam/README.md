# Teiko.Bio_Exam_Ben_Driggs
Technical Exam for an Engineering Internship at Teiko.Bio.


# Instructions
